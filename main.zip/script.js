function click1() {
    window.scrollTo(0, 625);
}
function click2(){
    window.scrollTo(0,970);
}
function click3(){
    window.scrollTo(0,1560);
}




function tikla1(){
    window.scrollTo(0,670);
}

function tikla2(){
    window.scrollTo(0,970);
}
function tikla3(){
    window.scrollTo(0,1560);
}




k=0.45;



setInterval(function(){
if(window.pageYOffset>171){
	k=k-0.001
	document.querySelector(".middler").style.opacity=k;
}
else if(window.pageYOffset<171){

document.querySelector(".middler").style.opacity=0.45;
}


},1)
